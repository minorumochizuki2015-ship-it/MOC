#!/usr/bin/env python3
"""
Setup script for APK Analysis System
APK分析システムのパッケージ化スクリプト
"""

from setuptools import setup, find_packages
import os
from pathlib import Path

# プロジェクト情報
PROJECT_NAME = "apk-analysis-system"
VERSION = "1.0.0"
DESCRIPTION = "Unity Hub風 APK分析システム"
LONG_DESCRIPTION = """
# APK Analysis System

Unity Hub風のモダンなインターフェースを持つAPK分析システムです。

## 主な機能

- **CompleteCloneGenerator**: Unity/IL2CPP専門分析
- **Enhanced APK Analyzer**: 高速バランス型分析  
- **MobSF Integration**: セキュリティ特化分析
- **Comprehensive Comparison**: 包括的比較分析

## 特徴

- 🎨 Unity Hub風のモダンUI
- 🚀 68.7%の性能改善を実現
- 🔍 多角的なAPK分析
- 📊 詳細な比較レポート
- 🎯 Unity/IL2CPPゲーム特化
"""

AUTHOR = "MOC Development Team"
AUTHOR_EMAIL = "dev@moc.example.com"
URL = "https://github.com/minorumochizuki2015-ship-it/MOC"

# 依存関係
INSTALL_REQUIRES = [
    "tkinter",
    "pathlib",
    "requests>=2.25.0",
    "numpy>=1.20.0",
    "pandas>=1.3.0",
    "scikit-learn>=1.0.0",
    "psutil>=5.8.0",
    "zipfile36>=0.1.3",
    "lxml>=4.6.0",
    "Pillow>=8.0.0",
    "matplotlib>=3.3.0",
    "seaborn>=0.11.0",
    "tqdm>=4.60.0",
    "colorama>=0.4.4",
    "python-magic>=0.4.24",
    "frida>=15.0.0",
]

# 開発用依存関係
EXTRAS_REQUIRE = {
    "dev": [
        "pytest>=6.0.0",
        "pytest-cov>=2.10.0",
        "black>=21.0.0",
        "flake8>=3.8.0",
        "mypy>=0.800",
        "pre-commit>=2.10.0",
    ],
    "docs": [
        "sphinx>=4.0.0",
        "sphinx-rtd-theme>=0.5.0",
    ]
}

# パッケージデータ
PACKAGE_DATA = {
    "": [
        "assets/*.svg",
        "assets/*.ico",
        "assets/*.png",
        "data/config/*.json",
        "data/ml_models/*.pkl",
        "data/frida_scripts/*.js",
        "comprehensive_analysis_reports/*.json",
        "comprehensive_analysis_reports/*.md",
    ]
}

# エントリーポイント
ENTRY_POINTS = {
    "console_scripts": [
        "apk-analyzer=apk_analyzer_app:main",
        "apk-analysis=apk_analyzer_app:main",
    ],
    "gui_scripts": [
        "apk-analyzer-gui=apk_analyzer_app:main",
    ]
}

# 分類子
CLASSIFIERS = [
    "Development Status :: 4 - Beta",
    "Intended Audience :: Developers",
    "Intended Audience :: Information Technology",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.8",
    "Programming Language :: Python :: 3.9",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Topic :: Security",
    "Topic :: Software Development :: Testing",
    "Topic :: System :: Systems Administration",
    "Topic :: Utilities",
]

def read_requirements():
    """requirements.txtから依存関係を読み込み"""
    requirements_path = Path(__file__).parent / "requirements.txt"
    if requirements_path.exists():
        with open(requirements_path, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip() and not line.startswith('#')]
    return INSTALL_REQUIRES

def get_package_data():
    """パッケージデータを動的に取得"""
    package_data = {}
    
    # アセットファイル
    assets_dir = Path(__file__).parent / "assets"
    if assets_dir.exists():
        package_data["assets"] = ["*.svg", "*.ico", "*.png", "*.jpg"]
    
    # 設定ファイル
    config_dir = Path(__file__).parent / "data" / "config"
    if config_dir.exists():
        package_data["data.config"] = ["*.json", "*.yaml", "*.yml"]
    
    # MLモデル
    ml_models_dir = Path(__file__).parent / "data" / "ml_models"
    if ml_models_dir.exists():
        package_data["data.ml_models"] = ["*.pkl", "*.joblib", "*.model"]
    
    # レポート
    reports_dir = Path(__file__).parent / "comprehensive_analysis_reports"
    if reports_dir.exists():
        package_data["comprehensive_analysis_reports"] = ["*.json", "*.md"]
    
    return package_data

def main():
    """セットアップ実行"""
    setup(
        name=PROJECT_NAME,
        version=VERSION,
        description=DESCRIPTION,
        long_description=LONG_DESCRIPTION,
        long_description_content_type="text/markdown",
        author=AUTHOR,
        author_email=AUTHOR_EMAIL,
        url=URL,
        packages=find_packages(),
        package_data=get_package_data(),
        include_package_data=True,
        install_requires=read_requirements(),
        extras_require=EXTRAS_REQUIRE,
        entry_points=ENTRY_POINTS,
        classifiers=CLASSIFIERS,
        python_requires=">=3.8",
        zip_safe=False,
        keywords="apk analysis android unity il2cpp security reverse-engineering",
        project_urls={
            "Bug Reports": f"{URL}/issues",
            "Source": URL,
            "Documentation": f"{URL}/wiki",
        },
    )

if __name__ == "__main__":
    main()